import './App.css';

import {
  ChatBox,
  useGetMessages,
  useGetActivity,
  send,
} from '@tumbleddowntoearth/intelli-chat';

import { useEffect, useState } from 'react';

const App = () => {
  // {"id": "7gAIPVYwZAQcoLUz8d2VS07QT1s2", "name": "Alice"}
  // {"id": "BdNRsn6WU6XM3kMTEdbrT43QpWh1", "name": "Bob"}

  const [sender, setSender] = useState(
    JSON.parse(
      localStorage.getItem('from') ||
        '{"id": "7gAIPVYwZAQcoLUz8d2VS07QT1s2", "name": "Alice"}',
    ),
  );
  const [receiver, setReceiver] = useState(
    JSON.parse(
      localStorage.getItem('to') ||
        '{"id": "BdNRsn6WU6XM3kMTEdbrT43QpWh1", "name": "Bob"}',
    ),
  );

  const otherUser = { id: '6670ce00916f6f81cd61f75e', name: 'John' };

  // const page = 0;

  // const { messages, hasMore, initialized } = useGetMessages(
  //   page,
  //   sender.id,
  //   receiver.id,
  // );

  // const { activity } = useGetActivity(sender.id, [receiver.id, otherUser.id]);

  // const sendMessage = async () => {
  //   await send({
  //     message: 'hello',
  //     conversation_id,
  //     sender_id: sender.id,
  //     receiver_id: receiver.id,
  //   });
  // };

  // useEffect(() => {
  //   console.log(activity);
  // }, [activity]);

  // useEffect(() => {
  //   console.log(messages);
  // }, [messages]);

  const changeUser = () => {
    setReceiver(otherUser);
  };

  return (
    <div>
      <button onClick={changeUser}>Change User</button>
      <ChatBox
        sender={sender}
        receiver={receiver}
        observeUserIds={[receiver.id, otherUser.id]}
        isFullPage={false}
        containerHeight="500px"
        showUserAvatar={false}
        bgSender="red"
        bgReceiver="pink"
      />
    </div>
  );
};
export default App;
